from django.apps import AppConfig


class Framework04Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'framework_04'
